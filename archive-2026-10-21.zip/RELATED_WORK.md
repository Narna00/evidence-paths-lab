# Graph experiment references

[MulVAL, USENIX Security 2005](https://www.usenix.org/conference/14th-usenix-security-symposium/mulval-logic-based-network-security-analyzer) studies logical network-security reasoning from configuration and vulnerability facts.

[Exact Inference Techniques for the Analysis of Bayesian Attack Graphs](https://arxiv.org/abs/1510.02427) and [Cyclic Bayesian Attack Graphs](https://arxiv.org/abs/2005.06350) address probabilistic inference and cyclic attack-graph models.

[ATLAS, USENIX Security 2021](https://www.usenix.org/conference/usenixsecurity21/presentation/alsaheel) studies attack investigation using audit-log sequences. [ProvSec](https://link.springer.com/article/10.1007/s44227-023-00014-9) provides labeled system-provenance data.

These sources concern related reasoning and evidence tasks. The synthetic experiment uses deterministic reachability bounds and idealized validation selection.
