# Graph validation experiment

This package documents the synthetic graph experiment distributed with Evidence Paths Lab. The model, observations and validation policies concern reachability under incomplete evidence.

The implementation uses Python 3.12 or later and the standard library. `evidence_paths.py` evaluates a declared graph; `benchmark.py` generates and evaluates seeded graph families. MODEL.md in the repository defines the semantics. PILOT.md reports the measured outcomes; pilot-results.zip contains the raw artifacts.

The simulation assumes a complete candidate universe and a perfect unit-cost validation oracle. Its outcomes describe the modeled graph-query task.
