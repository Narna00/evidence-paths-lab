# Evidence-aware validation selection

## Question

How does a validation-selection policy resolve a reachability query when the availability of candidate transitions is incompletely observed?

## Model

The experiment represents transitions as directed edges. Trusted, current and consistent validations determine TRUE or FALSE labels; missing or conflicting validation produces UNKNOWN. Lower and upper graphs bound reachability. Validation policies select unknown edges and receive their Boolean ground truth from a perfect oracle.

## Evaluation

The experiment compares random selection, path-first selection and a branch/corridor heuristic. Observation-only rules provide context for decision errors when missing transitions are treated as absent. The comparison records coverage, false-safe decisions, false-confirmed decisions, declared loss, validation count and runtime.

The benchmark isolates graph-selection behavior from acquisition costs, incorrect validators and application-state modeling.
