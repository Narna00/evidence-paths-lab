# Transition evidence acquisition

A transition observation describes a specific capability under recorded conditions. The acquisition record associates the principal, target, snapshot, request, effect, time and collection source with a stable transition identifier.

A valid positive control establishes that the test identity and service operate as expected. A boundary probe changes the condition being tested while retaining the relevant controls. Missing observations remain unresolved. Reports derived from one underlying observation share an origin identifier.

The evidence ledger includes scenario and family IDs, snapshot ID, source commit, image digest, configuration, principal, vantage point, tool version, input/output hashes, origin ID, ground-truth method, validation cost and collection errors. A configuration ledger and an independent controlled check establish the assigned transition label.

Lab deployments use isolated virtual networks and synthetic records. Radio-layer behavior requires owned radio hardware and appropriate capture conditions; offline graph simulation does not measure RF behavior.
