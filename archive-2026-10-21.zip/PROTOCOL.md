# Synthetic graph evaluation protocol

## Design

The exploratory simulation uses four graph families: layered, cyclic, bottleneck and random. Each family contains 30 seeded graphs with 12 nodes. The random family provides an additional topology-sensitivity condition. All generators were available during development; the design was not preregistered.

Candidate transitions have synthetic Boolean truth, with per-edge truth probability 0.68. Observation inclusion, corruption, expiry, re-export and conflict follow the probabilities in `benchmark.py:generate`. Initial trusted observations are sparse and correct. Validation returns ground truth at unit cost.

Maximum budgets are 0, 2, 5 and 10. The design produces 120 graphs and 2,400 method/budget rows. The graph and seed form the paired unit; rows at different budgets and methods share that unit.

## Methods

| Method | Evidence rule | Validation policy |
|---|---|---|
| optimistic | Any current positive report includes the transition | None |
| two_origins | Two positive origin IDs include the transition | None |
| bounds_random | Trusted lower and upper graphs | Random unknown edge |
| bounds_path_first | Trusted lower and upper graphs | First unknown edge on a shortest possible path |
| bounds_gain | Trusted lower and upper graphs | Branch-resolution and corridor-reduction heuristic |

Observation-only rules receive no additional validation. Primary planning comparisons use equal maximum budgets; actual validations used are reported because methods can stop early.

## Measures

False-safe decisions report `unreachable_in_model` when the true candidate graph is reachable. False-confirmed decisions report `reachable` when it is not. Abstention denotes an unresolved query. Coverage is the fraction of resolved queries.

Declared loss is `10 × false-safe + 3 × false-confirmed + abstention`. The weights are simulation choices. Validation count and compute runtime are reported separately. Correct oracle answers and candidate completeness constrain the interpretation of the observed error rates.

## Analysis

Paired loss differences compare bounds_gain with path-first and random validation within each family and budget. Negative values favor bounds_gain. Pointwise 95% percentile intervals use 1,000 deterministic bootstrap resamples of the 30 seeds. The intervals have no multiplicity adjustment and describe exploratory comparisons.

Additional experimental factors include source-lineage dependence, evidence expiry, validation errors, heterogeneous costs, omitted transitions and conjunctive or stateful prerequisites. These factors are outside the reported simulation's ideal validation assumptions.

## Reproduction

```sh
python benchmark.py --seeds 30 --output benchmark-results
```

Outputs include graph and truth fixtures, raw JSONL rows, summaries and hashes. Semantic outcomes reproduce from source and seed; runtime and environment-dependent hashes can vary. The environment ledger records Python, platform, invocation and source hashes. Integrity verification depends on a trusted manifest.
